library(testthat)
test_check("rgbif")